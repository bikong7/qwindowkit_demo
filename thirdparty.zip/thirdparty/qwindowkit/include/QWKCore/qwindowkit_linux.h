// Copyright (C) 2023-2024 Stdware Collections (https://www.github.com/stdware)
// Copyright (C) 2021-2023 wangwenx190 (Yuhang Zhao)
// SPDX-License-Identifier: Apache-2.0

#ifndef QWINDOWKIT_LINUX_H
#define QWINDOWKIT_LINUX_H


#endif // QWINDOWKIT_LINUX_H
